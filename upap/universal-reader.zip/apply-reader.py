import re, os, glob, json
OK = True
# 1) تعديل مسارات الوكلاء لتستخدم القارئ الشامل
for a in ["invoice-reader", "contract-reviewer"]:
    f = f"app/api/agents/{a}/route.ts"
    if not os.path.exists(f):
        print("لم أجد", f); OK = False; continue
    s = open(f, encoding="utf-8").read()
    if "readUpload" in s:
        print(a, ": مُعدَّل سابقاً"); continue
    pat = re.compile(r'const isPdf = [\s\S]*?(?=\n\s*if \(notes\))')
    new, n = pat.subn('const read = await readUpload(Buffer.from(arrayBuffer), file.name, file.type);\n    let extractedText = read.text;\n    const imageBase64: string | undefined = read.imageBase64;\n', s, count=1)
    if n != 1:
        print(a, ": لم يطابق النمط، لم أعدّل"); OK = False; continue
    new = 'import { readUpload } from "../../../../lib/readUpload";\n' + new
    open(f, "w", encoding="utf-8").write(new)
    print(a, ": تم")

# 2) إعداد Next ليتعامل مع المكتبات الثقيلة بشكل صحيح
PK = ["sharp", "@napi-rs/canvas", "pdf-parse", "unpdf", "heic-convert", "mammoth", "exceljs"]
cfgs = glob.glob("next.config.*")
if not cfgs:
    open("next.config.js", "w").write("/** @type {import('next').NextConfig} */\nconst nextConfig = { experimental: { serverComponentsExternalPackages: %s } };\nmodule.exports = nextConfig;\n" % json.dumps(PK))
    print("أُنشئ next.config.js")
else:
    c = cfgs[0]; s = open(c).read()
    if "serverComponentsExternalPackages" in s:
        print(c, ": فيه الإعداد سابقاً")
    elif "experimental" in s:
        print(c, ": فيه experimental، أرسل لي محتوى الملف"); OK = False
    else:
        new, n = re.subn(r'(nextConfig[^=\n]*=\s*\{)', r'\1\n  experimental: { serverComponentsExternalPackages: %s },' % json.dumps(PK), s, count=1)
        if n == 1:
            open(c, "w").write(new); print(c, ": تم")
        else:
            print(c, ": شكل غير متوقع، أرسل لي محتواه"); OK = False
print("النتيجة:", "نجاح" if OK else "يحتاج مراجعة")
