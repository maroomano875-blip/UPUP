import re, sys
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "geminiModels" in a:
    print("ai.ts مُعدَّل سابقاً"); sys.exit(0)
errs = []

# 1) تجاهل نماذج البيئة السيئة (مثل nemotron-safety)
old = 'const out = [...envList.filter((x) => (badUntil.get(x) ?? 0) <= now), ...ranked, "openrouter/free"];'
if old not in a: errs.append("pickModels out")
else:
    a = a.replace(old, 'const BAD = /(-vl|vision|guard|moderation|embed|audio|tts|image|safety|lyria|clip|music|laguna|inkling)/i;\n  const out = [...envList.filter((x) => (badUntil.get(x) ?? 0) <= now && (vision || !BAD.test(x))), ...ranked, "openrouter/free"];', 1)

# 2) دالة Gemini جديدة تكتشف النموذج المتاح تلقائياً
pat = re.compile(r'// ── Google Gemini \(احتياطي\) ──.*?(?=// ── الواجهة العامة)', re.S)
new_gemini = '''// ── Google Gemini: يكتشف أحدث نموذج flash متاح لمفتاحك تلقائياً ──
let gcache: { at: number; ids: string[] } | null = null;

async function geminiModels(key: string): Promise<string[]> {
  if (gcache && Date.now() - gcache.at < 3600_000) return gcache.ids;
  let found: string[] = [];
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 8000);
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=${key}`, { signal: ctl.signal });
    clearTimeout(t);
    if (res.ok) {
      const data = (await res.json()) as { models?: { name: string; supportedGenerationMethods?: string[] }[] };
      found = (data.models ?? [])
        .filter((m) => (m.supportedGenerationMethods ?? []).includes("generateContent"))
        .map((m) => m.name.replace(/^models\\//, ""))
        .filter((n) => /^gemini-\\d+(\\.\\d+)?-flash(-\\d+)?$/.test(n))
        .sort((x, y) => parseFloat(y.match(/gemini-(\\d+(?:\\.\\d+)?)/)![1]) - parseFloat(x.match(/gemini-(\\d+(?:\\.\\d+)?)/)![1]));
    }
  } catch {
    /* نكمل بالقائمة الاحتياطية */
  }
  const ids = Array.from(new Set([...(process.env.GEMINI_MODEL ? [process.env.GEMINI_MODEL] : []), ...found, "gemini-flash-latest"]));
  gcache = { at: Date.now(), ids };
  return ids;
}

async function callOneGemini(model: string, key: string, req: AIRequest): Promise<AIResponse> {
  const parts: unknown[] = [{ text: `${req.systemPrompt}\\n\\n${req.userText}` }];
  if (req.imageBase64) parts.push({ inline_data: { mime_type: "image/jpeg", data: req.imageBase64 } });
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 60000);
  const start = Date.now();
  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts }],
        generationConfig: { temperature: req.temperature ?? 0.1, responseMimeType: "application/json" },
      }),
    });
    if (!res.ok) throw new Error(`Gemini ${res.status} (${model}): ${(await res.text().catch(() => "")).slice(0, 140)}`);
    const data = await res.json();
    const text: string = data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    if (!text.trim()) throw new Error(`رد فارغ من Gemini (${model})`);
    return { text, provider: "gemini", model: `gemini/${model}`, latency_ms: Date.now() - start };
  } catch (e) {
    if ((e as Error).name === "AbortError") throw new Error(`انتهت مهلة Gemini (${model})`);
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

async function callGemini(req: AIRequest): Promise<AIResponse> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY مفقود");
  const avoid = req.avoidModels ?? [];
  const now = Date.now();
  const ids = (await geminiModels(key)).filter((m) => !avoid.includes(`gemini/${m}`) && (badUntil.get(`gemini/${m}`) ?? 0) <= now);
  const errors: string[] = [];
  for (const m of ids.slice(0, 3)) {
    try {
      return await callOneGemini(m, key, req);
    } catch (e) {
      badUntil.set(`gemini/${m}`, Date.now() + BAD_MS);
      errors.push((e as Error).message.replace(/\\s+/g, " ").slice(0, 120));
    }
  }
  throw new Error(errors.join(" ; ") || "لا نموذج Gemini متاح");
}

'''
a, n = pat.subn(lambda m: new_gemini, a, count=1)
if n != 1: errs.append("كتلة Gemini")

# 3) ترتيب المزودين: Groq ← Gemini ← OpenRouter
pat2 = re.compile(r'export async function generateResponse\(req: AIRequest\): Promise<AIResponse> \{.*?(?=// استخراج JSON متسامح)', re.S)
new_gen = '''export async function generateResponse(req: AIRequest): Promise<AIResponse> {
  const errors: string[] = [];
  const avoid = req.avoidModels ?? [];

  // 1) Groq (نص فقط، إن وُجد مفتاحه)
  if (process.env.GROQ_API_KEY && !req.imageBase64 && !avoid.some((x) => x.startsWith("groq/"))) {
    try {
      return await callGroq(req);
    } catch (e) {
      errors.push("Groq: " + (e as Error).message.slice(0, 150));
      console.warn("[AI] Groq فشل:", (e as Error).message);
    }
  }
  // 2) Gemini (يدعم الصور، ويكتشف النموذج المتاح)
  if (process.env.GEMINI_API_KEY) {
    try {
      return await callGemini(req);
    } catch (e) {
      errors.push("Gemini: " + (e as Error).message.slice(0, 200));
      console.warn("[AI] Gemini فشل:", (e as Error).message);
    }
  }
  // 3) OpenRouter (مجاني، متقلب)
  try {
    return await callOpenRouter(req);
  } catch (e) {
    errors.push("OpenRouter: " + (e as Error).message.slice(0, 300));
  }
  throw new Error("تعذّر الوصول لأي نموذج. " + errors.join(" | "));
}

'''
a, n = pat2.subn(lambda m: new_gen, a, count=1)
if n != 1: errs.append("generateResponse")
if errs:
    print("لم يُعدَّل:", errs); sys.exit(1)
open(g, "w", encoding="utf-8").write(a)
print("تم تعديل ai.ts"); print("النتيجة: نجاح")
