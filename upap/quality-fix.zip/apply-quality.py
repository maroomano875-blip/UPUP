import re, sys
# ---------- createAgent.ts ----------
f = "core/factory/createAgent.ts"
s = open(f, encoding="utf-8").read()
if "leafScore" in s:
    print("createAgent مُعدَّل سابقاً")
else:
    errs = []
    helpers = '''
// ── جودة الرد: عدّ القيم الفعلية في JSON وبناء نص المستخدم ──
function leafScore(v: unknown, key = ""): number {
  if (key === "confidence_score" || key === "warnings") return 0;
  if (v === null || v === undefined) return 0;
  if (typeof v === "string") {
    const t = v.trim().toLowerCase();
    return t && t !== "—" && t !== "-" && t !== "null" && t !== "unknown" ? 1 : 0;
  }
  if (typeof v === "number") return v !== 0 ? 1 : 0;
  if (Array.isArray(v)) return v.reduce((a: number, x) => a + leafScore(x), 0);
  if (typeof v === "object") return Object.entries(v as Record<string, unknown>).reduce((a, [k, x]) => a + leafScore(x, k), 0);
  return 0;
}

function buildUserText(extractedText: string, retry = false): string {
  const note =
    "ملاحظة: النص التالي مستخرج آلياً من ملف، وقد يكون ترتيب الأجزاء داخل السطر الواحد مقلوباً في العربية. اقرأه كاملاً وأعد بناء المعنى. المستند يحتوي نصاً فعلياً فلا تقل إنه فارغ.";
  const again = retry ? "\\nالمحاولة السابقة أرجعت حقولاً فارغة رغم وجود محتوى؛ استخرج كل الحقول الممكنة." : "";
  return `${note}${again}\\n\\n[نص المستند]\\n${extractedText}\\n\\nأعد JSON فقط.`;
}
'''
    m = re.search(r'import \{ audit \} from "\.\./engine/audit";\n', s)
    if not m: errs.append("لم أجد سطر استيراد audit")
    else: s = s[:m.end()] + helpers + s[m.end():]

    # 1) userText للمحاولة الأولى
    s2, n = re.subn(r'userText: `\$\{input\.extractedText\}[^`]*`,', 'userText: buildUserText(input.extractedText),', s, count=1)
    if n != 1: errs.append("لم أجد userText الأولى")
    s = s2

    # 2) كتلة تحليل JSON مع إعادة المحاولة
    pat = re.compile(r'let rawOutput: Record<string, unknown>;\s*try \{.*?\n(?=\s*const confidence = )', re.S)
    block = '''let rawOutput: Record<string, unknown> = {};
        {
          const tried: string[] = [String(aiRes.model)];
          let cur = aiRes;
          let best: Record<string, unknown> | null = null;
          let bestScore = -1;
          for (let attempt = 0; attempt < 2; attempt++) {
            try {
              const obj = extractJSON(cur.text) as Record<string, unknown>;
              const sc = leafScore(obj);
              if (sc > bestScore) { best = obj; bestScore = sc; }
              const shortDoc = input.extractedText.trim().length < 40 && !input.imageBase64;
              if (sc >= 3 || shortDoc) break;
              console.warn("[createAgent] رد شبه فارغ من", cur.model, "- إعادة المحاولة بنموذج آخر");
            } catch {
              console.error("[createAgent] JSON parse failed. model:", cur.model, "len:", String(cur.text ?? "").length, "head:", String(cur.text ?? "").slice(0, 400));
            }
            if (attempt === 1) break;
            try {
              cur = await generateResponse({
                systemPrompt: buildPrompt(config, input),
                userText: buildUserText(input.extractedText, true),
                imageBase64: input.imageBase64,
                avoidModels: tried,
              });
              tried.push(String(cur.model));
            } catch { break; }
          }
          if (!best) {
            throw new Error("فشل تحليل JSON. النموذج=" + String(cur.model ?? "?") + " | بداية الرد: " + String(cur.text ?? "").slice(0, 200).replace(/\\s+/g, " "));
          }
          rawOutput = best;
        }

        '''
    s2, n = pat.subn(lambda m: block, s, count=1)
    if n != 1: errs.append("لم أجد كتلة rawOutput")
    s = s2

    # 3) المراجع: يرى النص الأصلي، ولا يُسمح له بإفراغ البيانات
    rv_text = 'userText: "[النص الأصلي]\\n" + input.extractedText.slice(0, 6000) + "\\n\\n[المخرجات المطلوب مراجعتها]\\n" + JSON.stringify(rawOutput),'
    s2, n = re.subn(r'userText: JSON\.stringify\(rawOutput\),', lambda m: rv_text, s, count=1)
    if n != 1: errs.append("لم أجد userText للمراجع")
    s = s2
    old = 'finalOutput = extractJSON(reviewRes.text) as Record<string, unknown>;'
    if old not in s: errs.append("لم أجد سطر finalOutput")
    else:
        s = s.replace(old, '''{
          const rv = extractJSON(reviewRes.text) as Record<string, unknown>;
          if (leafScore(rv) >= leafScore(rawOutput) * 0.6) finalOutput = rv;
          else reviewerNotes = "تجاهلنا تعديل المراجع لأنه أفرغ البيانات";
        }''', 1)
    if errs:
        print("لم يُعدَّل createAgent:", " | ".join(errs)); sys.exit(1)
    open(f, "w", encoding="utf-8").write(s)
    print("تم تعديل createAgent")

# ---------- ai.ts ----------
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "avoidModels" in a:
    print("ai.ts مُعدَّل سابقاً")
else:
    errs = []
    def rep(old, new):
        global a
        if old not in a: errs.append(old[:40]); return
        a = a.replace(old, new, 1)
    rep("  maxTokens?: number;\n}", "  maxTokens?: number;\n  avoidModels?: string[]; // نماذج جُرّبت وفشلت\n}")
    rep("async function pickModels(vision: boolean): Promise<string[]> {", "async function pickModels(vision: boolean, avoid: string[] = []): Promise<string[]> {")
    rep("return Array.from(new Set(out));", "const uniq = Array.from(new Set(out));\n  const fresh = uniq.filter((x) => !avoid.includes(x));\n  return fresh.length ? fresh : uniq;")
    rep("const models = (await pickModels(Boolean(req.imageBase64))).slice(0, OR_MAX_ATTEMPTS);", "const models = (await pickModels(Boolean(req.imageBase64), req.avoidModels ?? [])).slice(0, OR_MAX_ATTEMPTS);")
    # محتوى نصي بسيط عند عدم وجود صورة (بعض المزودين يتجاهلون المصفوفة)
    rep('{ role: "user", content: userContent },', '{ role: "user", content: req.imageBase64 ? userContent : req.userText },')
    if errs:
        print("لم يُعدَّل ai.ts:", errs); sys.exit(1)
    open(g, "w", encoding="utf-8").write(a)
    print("تم تعديل ai.ts")
print("النتيجة: نجاح")
