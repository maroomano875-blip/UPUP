import re
f = "core/factory/createAgent.ts"
s = open(f, encoding="utf-8").read()
if "primary JSON parse failed" in s:
    print("مُعدَّل سابقاً"); raise SystemExit
pat = re.compile(r'try \{(\s*)rawOutput = extractJSON\(aiRes\.text\) as Record<string, unknown>;\s*\} catch \{\s*throw new Error\("[^"]*"\);\s*\}')
new_block = '''try {
        rawOutput = extractJSON(aiRes.text) as Record<string, unknown>;
      } catch {
        console.error("[createAgent] primary JSON parse failed. model:", aiRes.model, "len:", String(aiRes.text ?? "").length, "head:", String(aiRes.text ?? "").slice(0, 800));
        try {
          const fixRes = await generateResponse({
            systemPrompt: "Convert the user's text into ONE valid JSON object. Output ONLY the JSON object, with no markdown fences and no commentary.",
            userText: String(aiRes.text ?? "").slice(0, 12000),
          });
          rawOutput = extractJSON(fixRes.text) as Record<string, unknown>;
        } catch {
          throw new Error("فشل تحليل JSON من الوكيل الأساسي");
        }
      }'''
new, n = pat.subn(new_block, s, count=1)
if n == 1:
    open(f, "w", encoding="utf-8").write(new)
    print("تم"); print("النتيجة: نجاح")
else:
    print("لم يطابق النمط"); print("النتيجة: يحتاج مراجعة")
