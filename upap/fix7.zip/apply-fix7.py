import sys
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "CLOUDFLARE_ACCOUNT_ID" in a:
    print("ai.ts مُعدَّل سابقاً"); print("النتيجة: نجاح"); sys.exit(0)
errs = []
CF = '''// ── Cloudflare Workers AI (مجاني 10,000 وحدة/يوم، يدعم الصور) ──
async function callCloudflare(req: AIRequest): Promise<AIResponse> {
  const acc = process.env.CLOUDFLARE_ACCOUNT_ID;
  const tok = process.env.CLOUDFLARE_API_TOKEN;
  if (!acc || !tok) throw new Error("مفاتيح Cloudflare مفقودة");
  const model = process.env.CLOUDFLARE_MODEL ?? "@cf/meta/llama-4-scout-17b-16e-instruct";
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 45000);
  const start = Date.now();
  try {
    const res = await fetch(`https://api.cloudflare.com/client/v4/accounts/${acc}/ai/v1/chat/completions`, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${tok}` },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: req.systemPrompt },
          { role: "user", content: req.imageBase64 ? [{ type: "text", text: req.userText }, { type: "image_url", image_url: { url: `data:image/jpeg;base64,${req.imageBase64}` } }] : req.userText },
        ],
        temperature: req.temperature ?? 0.1,
        max_tokens: req.maxTokens ?? 3000,
      }),
    });
    if (!res.ok) throw new Error(`Cloudflare ${res.status}: ${(await res.text().catch(() => "")).slice(0, 160)}`);
    const data = await res.json();
    const text: string = data.choices?.[0]?.message?.content ?? "";
    if (!text.trim()) throw new Error("رد فارغ من Cloudflare");
    return { text, provider: "openrouter", model: `cloudflare/${model}`, latency_ms: Date.now() - start };
  } finally {
    clearTimeout(timer);
  }
}

'''
def rep(old, new, tag):
    global a
    if old not in a: errs.append(tag)
    else: a = a.replace(old, new, 1)
anchor = "// ── الواجهة العامة" if "// ── الواجهة العامة" in a else "export async function generateResponse"
rep(anchor, CF + anchor, "anchor")
rep("  // 3) OpenRouter (مجاني، متقلب)",
'''  // 2.7) Cloudflare Workers AI (احتياط مجاني، نص وصور)
  if (process.env.CLOUDFLARE_ACCOUNT_ID && process.env.CLOUDFLARE_API_TOKEN && !avoid.some((x) => x.startsWith("cloudflare/"))) {
    try {
      return await callCloudflare(req);
    } catch (e) {
      errors.push("Cloudflare: " + (e as Error).message.slice(0, 160));
      console.warn("[AI] Cloudflare فشل:", (e as Error).message);
    }
  }
  // 3) OpenRouter (مجاني، متقلب)''', "order")
if errs:
    print("لم يُعدَّل:", errs); sys.exit(1)
open(g, "w", encoding="utf-8").write(a)
print("تم تعديل ai.ts"); print("النتيجة: نجاح")
