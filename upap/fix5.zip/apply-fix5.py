import sys
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "حصة Gemini المجانية" in a:
    print("ai.ts مُعدَّل سابقاً"); print("النتيجة: نجاح"); sys.exit(0)
errs = []
def rep(old, new, tag):
    global a
    if old not in a: errs.append(tag)
    else: a = a.replace(old, new, 1)

# 1) نضيف نماذج flash-lite (لكل نموذج حصة يومية مستقلة)
rep("-flash(-\\d+)?$/", "-flash(-lite)?(-\\d+)?$/", "regex")
# 2) نجرّب حتى 8 نماذج، و429 لا يُعاد على النموذج نفسه بل ننتقل فوراً
rep("ids.slice(0, 4)", "ids.slice(0, 8)", "slice")
rep("const busy = /Gemini (503|429|500)/.test(msg);", "const busy = /Gemini (503|500)/.test(msg);", "busy")
rep("badUntil.set(`gemini/${m}`, Date.now() + BAD_MS);", "badUntil.set(`gemini/${m}`, Date.now() + (/Gemini 429/.test(msg) ? 180_000 : BAD_MS));", "bad429")
# 3) رسالة واضحة عند استنفاد الحصة
rep('throw new Error(errors.join(" ; ") || "لا نموذج Gemini متاح");',
    'if (errors.length && errors.every((x) => /Gemini 429/.test(x))) throw new Error("حصة Gemini المجانية استُنفدت لكل النماذج (تتجدد منتصف الليل بتوقيت المحيط الهادئ).");\n  throw new Error(errors.join(" ; ") || "لا نموذج Gemini متاح");', "msg")
if errs:
    print("لم يُعدَّل:", errs); sys.exit(1)
open(g, "w", encoding="utf-8").write(a)
print("تم تعديل ai.ts"); print("النتيجة: نجاح")
