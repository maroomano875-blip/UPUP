import re, sys
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "LANG_NAMES" in a:
    b = a.replace(' || /انتهت مهلة/.test(msg);', ';')
    if b != a:
        open(g, "w", encoding="utf-8").write(b); print("تم تحديث منطق المهلة"); print("النتيجة: نجاح")
    else:
        print("ai.ts مُعدَّل سابقاً"); print("النتيجة: نجاح")
    sys.exit(0)
errs = []

# 1) أرقام النماذج: نحتفظ بالبيئة آخراً (404 سابقاً) ونضيف flash-lite كاحتياط
old = 'const ids = Array.from(new Set([...(process.env.GEMINI_MODEL ? [process.env.GEMINI_MODEL] : []), ...found, "gemini-flash-latest"]));'
if old not in a: errs.append("ids")
else:
    a = a.replace(old, 'const ids = Array.from(new Set([...found, "gemini-flash-latest", "gemini-flash-lite-latest", ...(process.env.GEMINI_MODEL ? [process.env.GEMINI_MODEL] : [])]));', 1)

# 2) callGemini: إعادة محاولة عند 503/429، ولا حظر طويل إلا للـ404/400، وتجاهل الحظر إن حُظر الكل
pat = re.compile(r'async function callGemini\(req: AIRequest\): Promise<AIResponse> \{.*?\n\}\n', re.S)
new_cg = '''async function callGemini(req: AIRequest): Promise<AIResponse> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY مفقود");
  const avoid = req.avoidModels ?? [];
  const now = Date.now();
  const all = await geminiModels(key);
  let ids = all.filter((m) => !avoid.includes(`gemini/${m}`) && (badUntil.get(`gemini/${m}`) ?? 0) <= now);
  if (ids.length === 0) ids = all; // لا نترك القائمة فارغة أبداً
  const errors: string[] = [];
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  for (const m of ids.slice(0, 4)) {
    for (let k = 0; k < 3; k++) {
      try {
        return await callOneGemini(m, key, req);
      } catch (e) {
        const msg = (e as Error).message;
        const busy = /Gemini (503|429|500)/.test(msg);
        if (!busy) badUntil.set(`gemini/${m}`, Date.now() + BAD_MS); // 404/400: نموذج غير صالح
        if (busy && k < 2) { await sleep(1500 * (k + 1)); continue; } // ازدحام مؤقت: نعيد المحاولة
        errors.push(msg.replace(/\\s+/g, " ").slice(0, 120));
        break;
      }
    }
  }
  throw new Error(errors.join(" ; ") || "لا نموذج Gemini متاح");
}
'''
a, n = pat.subn(lambda m: new_cg, a, count=1)
if n != 1: errs.append("callGemini")

# 3) لغة المخرجات: نقرأ «اللغة: xx» من البرومبت ونفرضها على كل النصوص
old = 'export async function generateResponse(req: AIRequest): Promise<AIResponse> {\n'
if old not in a: errs.append("generateResponse")
else:
    inject = old + '''  req = { ...req, systemPrompt: req.systemPrompt + langDirective(req.systemPrompt) };
'''
    helper = '''const LANG_NAMES: Record<string, string> = { ar: "العربية", en: "English", fr: "Français", tr: "Türkçe", es: "Español", de: "Deutsch", it: "Italiano", pt: "Português", ru: "Русский", fa: "فارسی", ur: "اردو" };
function langDirective(prompt: string): string {
  const m = prompt.match(/اللغة\\s*:\\s*([A-Za-z]{2,3})(?:[-_][A-Za-z]{2,4})?/);
  if (!m) return "";
  const name = LANG_NAMES[m[1].toLowerCase()] ?? m[0].split(":")[1].trim();
  return `\\n\\nتعليمة إلزامية للّغة: اكتب كل القيم النصية في JSON (أسماء البنود، الشروح، التوصيات، الملخصات، التحذيرات) بلغة «${name}» فقط. أبقِ مفاتيح JSON وقيم المستويات (low/medium/high/critical) بالإنجليزية كما هي. لا تخلط لغتين.`;
}

'''
    a = a.replace(old, helper + inject, 1)
if errs:
    print("لم يُعدَّل:", errs); sys.exit(1)
open(g, "w", encoding="utf-8").write(a)
print("تم تعديل ai.ts"); print("النتيجة: نجاح")
