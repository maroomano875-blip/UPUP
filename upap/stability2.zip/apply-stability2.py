import sys
errs = []

# ---------- ai.ts ----------
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "callGroq" in a:
    print("ai.ts مُعدَّل سابقاً")
else:
    def rep(old, new):
        global a
        if old not in a: errs.append("ai.ts: " + old[:50]); return
        a = a.replace(old, new, 1)
    # فقط النماذج المجانية الرسمية (:free) ونصية فقط، وتجاهل الصغيرة جداً
    rep('''    if (vision) return (m.architecture?.input_modalities ?? []).includes("image");''',
        '''    const outs = m.architecture?.output_modalities ?? ["text"];
    if (outs.length !== 1 || outs[0] !== "text") return false; // لا صوت/صورة
    if (!m.id.endsWith(":free")) return false;                 // المجاني الرسمي فقط
    const sz = m.id.match(/(\\d+(?:\\.\\d+)?)b(?![a-z])/i);
    if (sz && Number(sz[1]) < 20) return false;               // النماذج الصغيرة ضعيفة بالعربية
    if (vision) return (m.architecture?.input_modalities ?? []).includes("image");''')
    rep('!/(-vl|vision|guard|moderation|embed|audio|tts|image|safety|nemotron)/i.test(m.id);',
        '!/(-vl|vision|guard|moderation|embed|audio|tts|image|safety|nemotron|lyria|clip|music|laguna|inkling)/i.test(m.id);')
    # Groq: بديل مجاني سريع (متوافق مع OpenAI)، للنص فقط
    rep('// ── Google Gemini (احتياطي) ──', '''// ── Groq (احتياطي مجاني وسريع، نص فقط) ──
async function callGroq(req: AIRequest): Promise<AIResponse> {
  const key = process.env.GROQ_API_KEY;
  if (!key) throw new Error("GROQ_API_KEY مفقود");
  if (req.imageBase64) throw new Error("Groq لا يدعم الصور هنا");
  const model = process.env.GROQ_MODEL ?? "llama-3.3-70b-versatile";
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 45000);
  const start = Date.now();
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: req.systemPrompt },
          { role: "user", content: req.userText },
        ],
        temperature: req.temperature ?? 0.1,
        max_tokens: req.maxTokens ?? 3000,
      }),
    });
    if (!res.ok) throw new Error(`Groq ${res.status}: ${(await res.text().catch(() => "")).slice(0, 160)}`);
    const data = await res.json();
    const text: string = data.choices?.[0]?.message?.content ?? "";
    if (!text.trim()) throw new Error("رد فارغ من Groq");
    return { text, provider: "openrouter", model: `groq/${model}`, latency_ms: Date.now() - start };
  } finally {
    clearTimeout(timer);
  }
}

// ── Google Gemini (احتياطي) ──''')
    # سلسلة المزودين: Groq (إن وُجد المفتاح) ← OpenRouter ← Gemini
    rep('''export async function generateResponse(req: AIRequest): Promise<AIResponse> {
  try {
    return await callOpenRouter(req);
  } catch (primaryError) {''', '''export async function generateResponse(req: AIRequest): Promise<AIResponse> {
  // Groq أولاً للنص فقط إن وُجد مفتاحه (أسرع وأكثر استقراراً من النماذج المجانية العشوائية)
  if (process.env.GROQ_API_KEY && !req.imageBase64 && !(req.avoidModels ?? []).some((x) => x.startsWith("groq/"))) {
    try {
      return await callGroq(req);
    } catch (e) {
      console.warn("[AI] Groq فشل:", (e as Error).message);
    }
  }
  try {
    return await callOpenRouter(req);
  } catch (primaryError) {''')
    if not errs:
        open(g, "w", encoding="utf-8").write(a)
        print("تم تعديل ai.ts")

# ---------- readUpload.ts ----------
f = "lib/readUpload.ts"
s = open(f, encoding="utf-8").read()
if "tableLines" in s:
    print("readUpload مُعدَّل سابقاً")
else:
    fn = '''// أسطر الجداول: pdf-parse يلصق أعمدة الأرقام (21,250,0002,500,000)، فنستخرجها بمواضعها ونفصلها بـ |
async function tableLines(b: Buffer): Promise<string> {
  try {
    const { getDocumentProxy } = await import('unpdf');
    const pdf = await getDocumentProxy(new Uint8Array(b));
    const out: string[] = [];
    for (let p = 1; p <= Math.min(pdf.numPages, 5); p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      type It = { s: string; x: number; y: number; w: number };
      const items: It[] = (tc.items as any[])
        .filter((i) => i.str && String(i.str).trim())
        .map((i) => ({ s: String(i.str), x: Number(i.transform[4]), y: Number(i.transform[5]), w: Number(i.width) || 0 }));
      items.sort((a, c) => c.y - a.y);
      const lines: It[][] = [];
      for (const it of items) {
        const l = lines.find((ln) => Math.abs(ln[0].y - it.y) < 3);
        if (l) l.push(it); else lines.push([it]);
      }
      for (const ln of lines) {
        const joined = ln.map((i) => i.s).join('');
        const rtl = (joined.match(/[\\u0600-\\u06FF\\uFB50-\\uFEFF]/g) || []).length > joined.replace(/\\s/g, '').length * 0.3;
        ln.sort((a, c) => (rtl ? c.x - a.x : a.x - c.x));
        let line = '';
        let prev: It | null = null;
        for (const it of ln) {
          if (prev) {
            const gap = rtl ? prev.x - (it.x + it.w) : it.x - (prev.x + prev.w);
            line += gap > 6 ? ' | ' : gap > 0.5 ? ' ' : '';
          }
          line += it.s;
          prev = it;
        }
        const cells = line.split(' | ');
        const numeric = cells.filter((c) => /\\d/.test(c)).length;
        if (cells.length >= 3 && numeric >= 2) out.push(line.trim());
      }
    }
    if (!out.length) return '';
    return '\\n\\n[أسطر الجداول: الأعمدة مفصولة بـ | والأرقام هنا هي المرجع الدقيق للكميات والأسعار والإجماليات]\\n' + out.join('\\n');
  } catch {
    return '';
  }
}

'''
    anchor = "async function pdfText(b: Buffer, warnings: string[]): Promise<string> {"
    if anchor not in s: errs.append("readUpload: لا مرساة pdfText")
    elif "if (t.length > 20) return t;" not in s: errs.append("readUpload: لا سطر return t")
    else:
        s = s.replace(anchor, fn + anchor, 1)
        s = s.replace("if (t.length > 20) return t;", "if (t.length > 20) return t + (await tableLines(b));", 1)
        open(f, "w", encoding="utf-8").write(s)
        print("تم تعديل readUpload")
if errs:
    print("أخطاء:", errs); sys.exit(1)
print("النتيجة: نجاح")
