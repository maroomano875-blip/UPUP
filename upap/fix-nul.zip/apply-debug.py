import re
f = "core/factory/createAgent.ts"
s = open(f, encoding="utf-8").read()
old = 'throw new Error("فشل تحليل JSON من الوكيل الأساسي");'
new = 'throw new Error("فشل تحليل JSON. النموذج=" + String(aiRes.model ?? "?") + " | الطول=" + String(aiRes.text ?? "").length + " | بداية الرد: " + String(aiRes.text ?? "").slice(0, 300).replace(/\\s+/g, " "));'
n = s.count(old)
if n == 0:
    print("لم أجد السطر - أرسل لي لقطة: grep -n 'JSON' core/factory/createAgent.ts")
else:
    open(f, "w", encoding="utf-8").write(s.replace(old, new))
    print("تم تعديل", n, "موضع")
print("هل طُبّق json-fix2؟", "primary JSON parse failed" in s)
