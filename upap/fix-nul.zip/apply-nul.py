f = "lib/readUpload.ts"
s = open(f, encoding="utf-8").read()
if "readUploadRaw" in s:
    print("مُعدَّل سابقاً"); raise SystemExit
s = s.replace("export async function readUpload(", "async function readUploadRaw(", 1)
s += '''

// تنظيف النص: Postgres يرفض \\u0000 والرموز التحكمية والمزدوجات اليتيمة
export function sanitizeText(t: string): string {
  return String(t ?? "")
    .replace(/[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F]/g, " ")
    .replace(/[\\uD800-\\uDBFF](?![\\uDC00-\\uDFFF])/g, "")
    .replace(/(^|[^\\uD800-\\uDBFF])[\\uDC00-\\uDFFF]/g, "$1");
}

export async function readUpload(b: Buffer, name = "", mime = ""): Promise<ReadResult> {
  const r = await readUploadRaw(b, name, mime);
  return { ...r, text: sanitizeText(r.text) };
}
'''
open(f, "w", encoding="utf-8").write(s)
print("تم تنظيف النص من NUL")
