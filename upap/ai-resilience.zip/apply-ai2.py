import sys
g = "core/engine/ai.ts"
a = open(g, encoding="utf-8").read()
if "badUntil" in a:
    print("ai.ts مُعدَّل سابقاً"); sys.exit(0)
errs = []
def rep(old, new):
    global a
    if old not in a: errs.append(old[:50]); return
    a = a.replace(old, new, 1)

rep('process.env.AI_TIMEOUT_MS ?? 40000', 'process.env.AI_TIMEOUT_MS ?? 30000')
rep('process.env.AI_MAX_ATTEMPTS ?? 3', 'process.env.AI_MAX_ATTEMPTS ?? 5')
# ذاكرة قصيرة للنماذج المعطّلة
rep('let cache: { at: number; models: ORModel[] } | null = null;',
    'let cache: { at: number; models: ORModel[] } | null = null;\nconst badUntil = new Map<string, number>(); // نموذج معطّل مؤقتاً\nconst BAD_MS = 10 * 60 * 1000;')
# استبعاد نماذج الرؤية/الحماية عند النص فقط
rep('const pool = live.filter((m) => (vision ? (m.architecture?.input_modalities ?? []).includes("image") : true));',
    'const now = Date.now();\n  const pool = live.filter((m) => {\n    if ((badUntil.get(m.id) ?? 0) > now) return false;\n    if (vision) return (m.architecture?.input_modalities ?? []).includes("image");\n    return !/(-vl|vision|guard|moderation|embed|audio|tts|image|safety|nemotron)/i.test(m.id);\n  });')
rep('const out = [...envList, ...ranked, "openrouter/free"];', 'const out = [...envList.filter((x) => (badUntil.get(x) ?? 0) <= now), ...ranked, "openrouter/free"];')
# تجميع الأخطاء + وسم المعطّل
rep('''  let last: unknown;
  for (const m of models) {
    try {
      return await callOneModel(m, req);
    } catch (e) {
      last = e;
      console.warn("[AI] فشل", (e as Error).message);
    }
  }
  throw last instanceof Error ? last : new Error("فشل OpenRouter");''',
'''  const errors: string[] = [];
  for (const m of models) {
    try {
      return await callOneModel(m, req);
    } catch (e) {
      const msg = (e as Error).message;
      badUntil.set(m, Date.now() + BAD_MS);
      errors.push(`${m}: ${msg.replace(/\\s+/g, " ").slice(0, 90)}`);
      console.warn("[AI] فشل", msg);
    }
  }
  throw new Error(`فشلت ${errors.length} محاولات | ` + errors.join(" ; "));''')
if errs:
    print("لم يُعدَّل:", errs); sys.exit(1)
open(g, "w", encoding="utf-8").write(a)
print("تم تعديل ai.ts"); print("النتيجة: نجاح")
