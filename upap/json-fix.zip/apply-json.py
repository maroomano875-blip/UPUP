import re, os
ok = True
# 1) core/engine/ai.ts : extractJSON
f = "core/engine/ai.ts"
s = open(f, encoding="utf-8").read()
if "parseLooseJSON" in s:
    print(f, ": مُعدَّل سابقاً")
else:
    new, n = re.subn(r'(export function extractJSON\(raw: string\): unknown \{)[\s\S]*?\n\}', r'\1\n  return parseLooseJSON(raw);\n}', s, count=1)
    if n == 1:
        new = 'import { parseLooseJSON } from "../../lib/parseLooseJSON";\n' + new
        open(f, "w", encoding="utf-8").write(new); print(f, ": تم")
    else:
        print(f, ": لم يطابق"); ok = False
# 2) core/factory/agentTemplate/agent.validator.ts
f = "core/factory/agentTemplate/agent.validator.ts"
s = open(f, encoding="utf-8").read()
if "parseLooseJSON" in s:
    print(f, ": مُعدَّل سابقاً")
else:
    new, n = re.subn(r'parsed = JSON\.parse\(cleaned\);(\s*)\} catch \{',
        r'parsed = parseLooseJSON(rawText);\1} catch {\n    console.error("[agent.validator] JSON parse failed. head:", String(rawText).slice(0, 600));', s, count=1)
    if n == 1:
        new = 'import { parseLooseJSON } from "../../../lib/parseLooseJSON";\n' + new
        open(f, "w", encoding="utf-8").write(new); print(f, ": تم")
    else:
        print(f, ": لم يطابق"); ok = False
print("النتيجة:", "نجاح" if ok else "يحتاج مراجعة")
